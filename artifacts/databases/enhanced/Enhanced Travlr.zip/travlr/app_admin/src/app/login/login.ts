import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';
import { AuthenticationService } from '../services/authentication';
import { User } from '../user';

@Component({
  selector: 'app-login',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './login.html',
  styleUrl: './login.css'
})
export class LoginComponent implements OnInit {

  // Stores login error messages shown to the user
  public formError: string = '';
  submitted = false;

  // Stores the login form values
  credentials = {
    name: '',
    email: '',
    password: ''
  };

  constructor(
    private router: Router,
    private authenticationService: AuthenticationService
  ) { }

  ngOnInit(): void {
  }

  // Validates the login form before attempting login
  public onLoginSubmit(): void {
    this.formError = '';
    if (!this.credentials.email || !this.credentials.password || !this.credentials.name) {
      this.formError = 'All fields are required, please try again';
      this.router.navigateByUrl('/login');
    } else {
      this.doLogin();
    }
  }

  // Sends login request and saves token if successful
  private doLogin(): void {
    const newUser = {
      name: this.credentials.name,
      email: this.credentials.email
    } as User;

    this.authenticationService.login(newUser, this.credentials.password)
      .subscribe({
        next: (value: any) => {
          if (value && value.token) {
            this.authenticationService.saveToken(value.token);
            this.router.navigate(['']);
          } else {
            this.formError = 'Login failed. Please try again.';
          }
        },
        error: (error: any) => {
          console.log('Login error:', error);
          this.formError = 'Invalid login credentials. Please try again.';
        }
      });
  }
}

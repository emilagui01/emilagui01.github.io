import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormBuilder, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { TripDataService } from '../services/trip-data.service';

@Component({
  selector: 'app-add-trip',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule],
  templateUrl: './add-trip.html',
  styleUrl: './add-trip.css'
})
export class AddTrip implements OnInit {
  addForm!: FormGroup;
  submitted = false;
  message: string = '';

  constructor(
    private formBuilder: FormBuilder,
    private router: Router,
    private tripService: TripDataService
  ) {}

  ngOnInit() {
    // Build add trip form with validation rules
    this.addForm = this.formBuilder.group({
      _id: [''],
      code: ['', [Validators.required, Validators.minLength(3)]],
      name: ['', [Validators.required, Validators.minLength(3)]],
      length: ['', [Validators.required, Validators.minLength(3)]],
      start: ['', Validators.required],
      resort: ['', [Validators.required, Validators.minLength(3)]],
      perPerson: ['', [Validators.required, Validators.pattern('^[0-9]+(\\.[0-9]{1,2})?$')]],
      image: ['', [Validators.required, Validators.pattern('^.+\\.(jpg|jpeg|png|webp)$')]],
      description: ['', [Validators.required, Validators.minLength(10)]],
    });
  }

  // Submit new trip if form is valid
  public onSubmit() {
    this.submitted = true;
    if (this.addForm.valid) {
      this.tripService.addTrip(this.addForm.value)
        .subscribe({
          next: (data: any) => {
            console.log(data);
            this.router.navigate(['']);
          },
          error: (error: any) => {
            console.log('Error: ', error);
            this.message = 'Unable to add trip. Please check the information and try again.';
          }
        });
    }
  }

  // Shortcut for accessing form controls in the template
  get f() {
    return this.addForm.controls;
  }
}

import { inject } from '@angular/core';
import { CanActivateFn, Router } from '@angular/router';
import { AuthenticationService } from './authentication';

// Protects routes that require a logged-in user
export const authGuard: CanActivateFn = () => {
    const authenticationService = inject(AuthenticationService);
    const router = inject(Router);

    // Allow access if the user is logged in
    if (authenticationService.isLoggedIn()) {
        return true;
    }

    // Redirect logged-out users to the login page
    router.navigate(['/login']);
    return false;
};
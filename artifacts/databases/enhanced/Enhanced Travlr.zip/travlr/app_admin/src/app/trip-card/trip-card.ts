import { Component, Input } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Router } from '@angular/router';
import { Trip } from '../models/trip';
import { AuthenticationService } from '../services/authentication';
import { TripDataService } from '../services/trip-data.service';

@Component({
  selector: 'app-trip-card',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './trip-card.html',
  styleUrl: './trip-card.css'
})
export class TripCard {
  // Trip data passed in from the trip listing component
  @Input('trip') trip: any;

  constructor(
    private router: Router,
    private authenticationService: AuthenticationService,
    private tripDataService: TripDataService
  ) { }

  // Stores selected trip code and opens the edit page
  public editTrip(trip: Trip) {
    localStorage.removeItem('tripCode');
    localStorage.setItem('tripCode', trip.code);
    this.router.navigate(['edit-trip']);
  }

  // Confirms and deletes the selected trip
  public deleteTrip(trip: Trip): void {
  if (confirm(`Are you sure you want to delete ${trip.name}?`)) {
    this.tripDataService.deleteTrip(trip.code)
      .subscribe({
        next: () => {
          window.location.reload();
        },
        error: (error: any) => {
          console.log('Error deleting trip:', error);
          alert('Unable to delete trip. Please try again.');
        }
      });
  }
}

  // Checks if user is logged in before showing admin buttons
  public isLoggedIn(): boolean {
    return this.authenticationService.isLoggedIn();
  }
}
const mongoose = require ('mongoose');
const Trip = require('../models/travlr'); //Register model
const Model = mongoose.model('trips');

// GET: /trips - Lists all trips
// Returns all trip records from MongoDB
const tripsList = async (req, res) => {
  try {
    const trips = await Trip
      .find({})
      .exec();

    return res
      .status(200)
      .json(trips);
  } catch (err) {
    return res
      .status(500)
      .json({
        "message": "Error retrieving trips",
        "error": err.message
      });
  }
};
        

// GET: /trips/:tripCode - Finds a single trip by code
const tripsFindByCode = async (req, res) => {
  try {
    const trip = await Trip
      .findOne({ 'code': req.params.tripCode })
      .exec();

    if (!trip) {
      return res
        .status(404)
        .json({ "message": "Trip not found" });
    }

    return res
      .status(200)
      .json(trip);
  } catch (err) {
    return res
      .status(500)
      .json({
        "message": "Error retrieving trip",
        "error": err.message
      });
  }
};

// POST: /trips - Adds a new Trip
// Validates and saves trip data to MongoDB
const tripsAddTrip = async (req, res) => {
  try {
    const newTrip = {
      code: req.body.code,
      name: req.body.name,
      length: req.body.length,
      start: req.body.start,
      resort: req.body.resort,
      perPerson: req.body.perPerson,
      image: req.body.image,
      description: req.body.description
    };

    const trip = await Trip.create(newTrip);

    return res
      .status(201)
      .json(trip);
  } catch (err) {
    if (err.name === 'ValidationError') {
      return res
        .status(400)
        .json({
          message: 'Trip validation failed',
          errors: err.errors
        });
    }

    return res
      .status(500)
      .json({
        message: 'Error adding trip',
        error: err.message
      });
  }
};

// DELETE: /trips/:tripCode - Deletes a trip
// Requires a valid trip code and returns a status message
const tripsDeleteTrip = async (req, res) => {
    try {
        const q = await Trip
            .findOneAndDelete({ 'code': req.params.tripCode })
            .exec();

        if (!q) {
            return res
                .status(404)
                .json({ "message": "Trip not found" });
        }

        return res
            .status(200)
            .json({ "message": "Trip deleted successfully" });
    } catch (err) {
        return res
            .status(500)
            .json({ "message": "Error deleting trip", "error": err });
    }
};

// PUT: /trips/:tripCode - Updates a trip
// Validates updated trip data before saving changes
const tripsUpdateTrip = async (req, res) => {
  try {
    const updatedTrip = await Trip
      .findOneAndUpdate(
        { 'code': req.params.tripCode },
        {
          code: req.body.code,
          name: req.body.name,
          length: req.body.length,
          start: req.body.start,
          resort: req.body.resort,
          perPerson: req.body.perPerson,
          image: req.body.image,
          description: req.body.description
        },
        {
          new: true,
          runValidators: true
        }
      )
      .exec();

    if (!updatedTrip) {
      return res
        .status(404)
        .json({ "message": "Trip not found" });
    }

    return res
      .status(200)
      .json(updatedTrip);
  } catch (err) {
    if (err.name === 'ValidationError' || err.name === 'CastError') {
      return res
        .status(400)
        .json({
          "message": "Trip update validation failed",
          "errors": err.errors || err.message
        });
    }

    return res
      .status(500)
      .json({
        "message": "Error updating trip",
        "error": err.message
      });
  }
};

module.exports = {
    tripsList,
    tripsFindByCode,
    tripsAddTrip,
    tripsUpdateTrip,
    tripsDeleteTrip
};
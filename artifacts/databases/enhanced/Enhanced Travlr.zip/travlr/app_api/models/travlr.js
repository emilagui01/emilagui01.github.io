const mongoose = require('mongoose');

// Define the trip schema with validation rules
const tripSchema = new mongoose.Schema({
  code: {
    type: String,
    required: [true, 'Trip code is required'],
    trim: true,
    minlength: [3, 'Trip code must be at least 3 characters'],
    index: true
  },
  name: {
    type: String,
    required: [true, 'Trip name is required'],
    trim: true,
    minlength: [3, 'Trip name must be at least 3 characters'],
    index: true
  },
  length: {
    type: String,
    required: [true, 'Trip length is required'],
    trim: true,
    minlength: [3, 'Trip length must be at least 3 characters']
  },
  start: {
    type: Date,
    required: [true, 'Start date is required']
  },
  resort: {
    type: String,
    required: [true, 'Resort is required'],
    trim: true,
    minlength: [3, 'Resort must be at least 3 characters']
  },
  perPerson: {
    type: Number,
    required: [true, 'Price per person is required'],
    min: [0, 'Price must be a positive number']
  },
  image: {
    type: String,
    required: [true, 'Image name is required'],
    trim: true,
    match: [/^.+\.(jpg|jpeg|png|webp)$/i, 'Image must end in .jpg, .jpeg, .png, or .webp']
  },
  description: {
    type: String,
    required: [true, 'Description is required'],
    trim: true,
    minlength: [10, 'Description must be at least 10 characters']
  }
});

const Trip = mongoose.model('trips', tripSchema);
module.exports = Trip;

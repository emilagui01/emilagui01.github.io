const express = require('express');
const router = express.Router();
const jwt = require('jsonwebtoken'); // Enable JSON Web Tokens

//This is where we import the controllers we will route
const tripsController = require('../controllers/trips');
const authController = require('../controllers/authentication');

// Method to authenticate our JWT
function authenticateJWT(req, res, next) {
  const authHeader = req.headers['authorization'];

  // Check that authorization header exists
  if (!authHeader) {
    console.log('Auth Header Required but NOT PRESENT!');
    return res.sendStatus(401);
  }

  const headers = authHeader.split(' ');

  // Check that header is in Bearer token format
  if (headers.length !== 2 || headers[0] !== 'Bearer') {
    console.log('Invalid Authorization Header format');
    return res.sendStatus(401);
  }

  const token = headers[1];

  // Check that token exists
  if (!token) {
    console.log('Null Bearer Token');
    return res.sendStatus(401);
  }

  // Verify token before allowing request to continue
  jwt.verify(token, process.env.JWT_SECRET, (err, verified) => {
    if (err) {
      console.log('JWT verification failed');
      return res.sendStatus(401);
    }

    req.auth = verified;
    next();
  });
}

// define route for login endpoint
router
  .route('/login')
  .post(authController.login);

// define route for registration endpoint
router
  .route('/register')
  .post(authController.register);

// define route for our trips endpoint
router
  .route('/trips')
  .get(tripsController.tripsList)
  .post(authenticateJWT, tripsController.tripsAddTrip);

// GET Method routes tripsFindByCode - requires parameter
// PUT Method routes tripsUpdateTrip - requires parameter
router
  .route('/trips/:tripCode')
  .get(tripsController.tripsFindByCode)
  .put(authenticateJWT, tripsController.tripsUpdateTrip)
  .delete(authenticateJWT, tripsController.tripsDeleteTrip);

module.exports = router;